Project Teammates:
Vishal Murugan - vmuruga
Prashanth Ramesh - pramesh2
Ashima Singh - asingh26
Jeris Alan Jawahar - jjawaha

List of files changed:
Buffer.java
BasicBufferMgr.java
LogIterator.java
LogMgr.java
LogRecordIterator.java
RecoveryMgr.java
CheckpointRecord.java
CommitRecord.java
LogRecord.java
RecoveryMgr.java
RollbackRecord.java
SetIntRecord.java
SetStringRecord.java
StartRecord.java

List of files added:
ForwardLogIterator

List of test files added:
BufferTest.java
BufferTest2.java
RecoveryTest.java
RecoveryTest2.java

The test files can be found in the "test" package.
The test files can be run directly as a java application using the files in the "simpledb" package in the classpath.